"""Application configuration — env-driven, no secrets in source."""
from __future__ import annotations

import os
from functools import lru_cache
from ipaddress import ip_network
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- ES -----------------------------------------------------------
    elasticsearch_url: str = "http://elasticsearch:9200"
    elastic_user: str = "elastic"
    elastic_password: str = "changeme-elastic"

    # ---- API ---------------------------------------------------------
    api_secret_key: str = "dev-only-insecure-key"
    api_allowed_cidrs: str = "192.168.1.0/24,127.0.0.0/8"

    # ---- Paths -------------------------------------------------------
    model_path: str = "/app/model-lab/models"
    data_path: str = "/app/data"
    ml_code_path: str = "/app/ml"

    # ---- ML defaults -------------------------------------------------
    default_random_seed: int = 42
    default_train_test_split: float = 0.2
    default_feature_version: str = "v1"

    # ---- Logging -----------------------------------------------------
    log_level: str = "INFO"

    @property
    def allowed_networks(self) -> List[ip_network]:
        out: List[ip_network] = []
        for raw in (self.api_allowed_cidrs or "").split(","):
            raw = raw.strip()
            if not raw:
                continue
            try:
                out.append(ip_network(raw, strict=False))
            except ValueError:
                continue
        return out


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
