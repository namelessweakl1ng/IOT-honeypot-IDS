"""FastAPI entry point — exposes the dashboard API."""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from . import es_client, model_registry
from .config import settings

# ---- Logging ------------------------------------------------------
logging.basicConfig(
    level=settings.log_level,
    format="%(asctime)s %(levelname)s %(name)s | %(message)s",
)
log = logging.getLogger("api")

# ---- App ----------------------------------------------------------
app = FastAPI(
    title="IoT Honeypot IDS — Dashboard API",
    description="Sessions, detections, models, experiments, and replay endpoints.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ---- IP allow-list middleware -------------------------------------
@app.middleware("http")
async def ip_allowlist(request: Request, call_next):
    # Health check is always open so Docker healthchecks pass.
    if request.url.path in {"/health", "/"}:
        return await call_next(request)
    client_ip = request.client.host if request.client else "0.0.0.0"
    import ipaddress
    ip = ipaddress.ip_address(client_ip)
    if not any(ip in net for net in settings.allowed_networks):
        log.warning("rejected request from non-lab IP: %s", client_ip)
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={"detail": "client ip not in lab subnet"},
        )
    return await call_next(request)


# ---- Models (request bodies) --------------------------------------
class TrainingRequest(BaseModel):
    algorithm: str = "random_forest"
    dataset_version: str = "v1"
    feature_version: str = settings.default_feature_version
    seed: int = settings.default_random_seed
    notes: str = ""


class ReplayRequest(BaseModel):
    scenario_id: str
    target: str
    campaign_id: str | None = None


# ---- Routes -------------------------------------------------------
@app.get("/")
def root():
    return {"name": "iot-honeypot-ids", "version": app.version}


@app.get("/health")
def health():
    es_ok = es_client.ping()
    models_dir = Path(settings.model_path)
    models_ok = models_dir.exists()
    return {
        "status": "ok" if (es_ok and models_ok) else "degraded",
        "elasticsearch": "ok" if es_ok else "down",
        "models_dir": "ok" if models_ok else "missing",
        "version": app.version,
    }


@app.get("/events")
def events(
    size: int = 100,
    source_ip: str | None = None,
    device: str | None = None,
):
    query: dict = {"match_all": {}}
    if source_ip or device:
        must = []
        if source_ip:
            must.append({"term": {"source.ip": source_ip}})
        if device:
            must.append({"term": {"device.id": device}})
        query = {"bool": {"must": must}}
    return es_client.search_events(size=min(size, 500), query=query)


@app.get("/sessions")
def sessions(size: int = 50, source_ip: str | None = None):
    return {"sessions": es_client.search_sessions(size=min(size, 200), source_ip=source_ip)}


@app.get("/sessions/{session_id}")
def session_detail(session_id: str):
    out = es_client.get_session(session_id)
    if out is None:
        raise HTTPException(404, "session not found")
    return out


@app.get("/detections")
def detections(size: int = 50, session_id: str | None = None):
    return {"detections": es_client.search_detections(size=min(size, 200), session_id=session_id)}


@app.get("/models")
def models():
    return {"models": model_registry.list_models()}


@app.get("/models/{model_id}")
def model_detail(model_id: str):
    m = model_registry.get_model(model_id)
    if m is None:
        raise HTTPException(404, "model not found")
    return m


@app.post("/models/{model_id}/status")
def model_status(model_id: str, status: str):
    out = model_registry.update_status(model_id, status)
    if out is None:
        raise HTTPException(404, "model not found")
    return out


@app.get("/experiments")
def experiments():
    """Experiments live under model-lab/experiments/ as JSON files."""
    exp_dir = Path(settings.model_path).parent / "experiments"
    out = []
    if exp_dir.exists():
        for p in sorted(exp_dir.glob("*.json")):
            import json
            try:
                out.append(json.loads(p.read_text()))
            except Exception:
                continue
    return {"experiments": out}


@app.get("/metrics")
def metrics(model_id: str | None = None):
    if model_id:
        m = model_registry.get_model(model_id)
        return m["metrics"] if m else {}
    all_models = model_registry.list_models()
    return {m["model_id"]: m.get("metrics", {}) for m in all_models}


@app.post("/training")
def training(req: TrainingRequest):
    """Trigger a training run via the model-lab CLI (synchronously)."""
    import subprocess
    import sys

    ml_root = Path(settings.model_path).parent
    if not ml_root.exists():
        raise HTTPException(500, f"model-lab root missing: {ml_root}")

    cmd = [
        sys.executable, "-m", "model_lab.train",
        "--algorithm", req.algorithm,
        "--dataset-version", req.dataset_version,
        "--feature-version", req.feature_version,
        "--seed", str(req.seed),
    ]
    log.info("launching training: %s", " ".join(cmd))
    try:
        result = subprocess.run(
            cmd, cwd=str(ml_root), capture_output=True, text=True, timeout=600
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "training timed out (10 min)")
    except FileNotFoundError:
        raise HTTPException(500, "model_lab.train module not found")
    return {
        "returncode": result.returncode,
        "stdout_tail": result.stdout[-2000:],
        "stderr_tail": result.stderr[-2000:],
    }


@app.post("/replay")
def replay(req: ReplayRequest):
    """Trigger a replay scenario via the attacker runner."""
    import subprocess
    from pathlib import Path as P

    attacker_root = P(settings.model_path).parent.parent / "attacker"
    if not attacker_root.exists():
        raise HTTPException(500, f"attacker root missing: {attacker_root}")

    # Defensive: never accept arbitrary targets. The runner also enforces
    # this, but we double-check here.
    import ipaddress
    try:
        ip = ipaddress.ip_address(req.target)
    except ValueError:
        raise HTTPException(400, "target is not a valid IP")
    if not any(ip in net for net in settings.allowed_networks):
        raise HTTPException(400, f"target {req.target} not in lab subnet")

    runner = attacker_root / "run-scenario.sh"
    cmd = [str(runner), "--target", req.target, "--scenario", req.scenario_id]
    if req.campaign_id:
        cmd += ["--campaign-id", req.campaign_id]
    log.info("launching replay: %s", " ".join(cmd))
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "replay timed out (5 min)")
    return {
        "returncode": result.returncode,
        "stdout_tail": result.stdout[-2000:],
        "stderr_tail": result.stderr[-2000:],
    }
