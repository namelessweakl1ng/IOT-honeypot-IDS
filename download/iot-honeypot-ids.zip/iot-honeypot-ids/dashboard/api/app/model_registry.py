"""Lightweight ML model registry — reads/writes JSON metadata under model_path."""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import settings

log = logging.getLogger("model_registry")


def _models_dir() -> Path:
    p = Path(settings.model_path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def list_models() -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for entry in sorted(_models_dir().iterdir()):
        if not entry.is_dir():
            continue
        meta_file = entry / "metadata.json"
        if not meta_file.exists():
            continue
        try:
            out.append(json.loads(meta_file.read_text()))
        except Exception as exc:  # noqa: BLE001
            log.error("could not read metadata for %s: %s", entry.name, exc)
    return out


def get_model(model_id: str) -> Optional[Dict[str, Any]]:
    meta = _models_dir() / model_id / "metadata.json"
    if not meta.exists():
        return None
    return json.loads(meta.read_text())


def register_model(
    *,
    model_id: str,
    algorithm: str,
    dataset_version: str,
    feature_version: str,
    features: List[str],
    hyperparameters: Dict[str, Any],
    metrics: Dict[str, float],
    seed: int,
    status: str = "experimental",
    notes: str = "",
) -> Dict[str, Any]:
    """Persist a model registry entry. Never overwrites — caller must version."""
    entry = _models_dir() / model_id
    if entry.exists():
        raise FileExistsError(f"model {model_id} already exists")
    entry.mkdir(parents=True)
    meta = {
        "model_id": model_id,
        "algorithm": algorithm,
        "dataset_version": dataset_version,
        "feature_version": feature_version,
        "features": features,
        "hyperparameters": hyperparameters,
        "metrics": metrics,
        "seed": seed,
        "status": status,
        "notes": notes,
        "created_at": int(time.time()),
        "created_at_iso": _iso_now(),
    }
    (entry / "metadata.json").write_text(json.dumps(meta, indent=2))
    (entry / "README.md").write_text(_model_readme(meta))
    return meta


def update_status(model_id: str, status: str) -> Optional[Dict[str, Any]]:
    meta_path = _models_dir() / model_id / "metadata.json"
    if not meta_path.exists():
        return None
    meta = json.loads(meta_path.read_text())
    meta["status"] = status
    meta["updated_at_iso"] = _iso_now()
    meta_path.write_text(json.dumps(meta, indent=2))
    return meta


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _model_readme(meta: Dict[str, Any]) -> str:
    features_md = ", ".join(f"`{f}`" for f in meta["features"])
    return f"""# {meta['model_id']}

- Algorithm: `{meta['algorithm']}`
- Dataset version: `{meta['dataset_version']}`
- Feature version: `{meta['feature_version']}`
- Status: `{meta['status']}`
- Created: `{meta['created_at_iso']}`
- Random seed: `{meta['seed']}`

## Hyperparameters

```json
{json.dumps(meta['hyperparameters'], indent=2)}
```

## Metrics

```json
{json.dumps(meta['metrics'], indent=2)}
```

## Features

{features_md}

## Notes

{meta.get('notes', '')}
"""

