# Trained model artifacts

Each model lives in its own subdirectory:

```
model-v001/
├── model.joblib       # the trained estimator
├── scaler.joblib      # optional feature scaler (logistic_regression only)
├── metadata.json      # algorithm, hyperparameters, metrics, seed, status
└── README.md          # human-readable summary
```

Models are never overwritten. The model registry (FastAPI /model/{id}) reads
`metadata.json` to list / inspect / status-change models.

To train a new model:

```bash
python -m model_lab.train --algorithm random_forest --seed 42
```

To evaluate a held-out session-level split:

```bash
python -m model_lab.evaluate --model-id model-v001
```

To compare two models:

```bash
python -m model_lab.compare --model-ids model-v001 model-v002
```
