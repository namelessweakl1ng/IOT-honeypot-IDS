#!/usr/bin/env bash
# Start ELK + API on PC1.
set -euo pipefail
cd "$(dirname "$0")/../../dashboard"
[ -f .env ] || { echo "ERROR: dashboard/.env missing. Run scripts/setup/init.sh first." >&2; exit 1; }
echo "=== Starting ELK + API on PC1 ==="
docker compose up -d
echo "Waiting 90s for stack to become healthy..."
sleep 90
docker compose ps
echo "Kibana: http://localhost:5601"
echo "API:    http://localhost:8000/health"
