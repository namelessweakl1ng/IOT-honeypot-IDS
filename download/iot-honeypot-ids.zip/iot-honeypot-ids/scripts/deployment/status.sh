#!/usr/bin/env bash
# Status across PC1 + Pi (best-effort — assumes SSH access to the Pi).
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "=== PC1 status ==="
(cd dashboard && docker compose ps)

echo
echo "=== Pi status (via SSH, if configured) ==="
PI_SSH_USER="${PI_SSH_USER:-pi}"
PI_IP="${PI_IP:-}"
if [ -n "$PI_IP" ] && command -v ssh >/dev/null; then
  ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no \
    "${PI_SSH_USER}@${PI_IP}" \
    "cd ~/iot-honeypot-ids/pi && ./scripts/status.sh" 2>/dev/null || \
    echo "(could not SSH to Pi at ${PI_IP})"
else
  echo "(PI_IP not set in .env — skipping Pi status)"
fi
