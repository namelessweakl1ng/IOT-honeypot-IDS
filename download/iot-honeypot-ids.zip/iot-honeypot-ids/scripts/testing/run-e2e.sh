#!/usr/bin/env bash
# End-to-end test: attack scenario -> telemetry -> session -> detection.
# Usage: ./scripts/testing/run-e2e.sh --target 192.168.1.50
set -euo pipefail
cd "$(dirname "$0")/../.."

TARGET=""
SCENARIO="${SCENARIO:-ssh-bruteforce}"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2 ;;
    --scenario) SCENARIO="$2"; shift 2 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done
[ -n "$TARGET" ] || { echo "ERROR: --target is required" >&2; exit 2; }

echo "=== E2E: $SCENARIO against $TARGET ==="

# 1. Run the attacker scenario
echo ">> launching attacker scenario"
./attacker/run-scenario.sh --target "$TARGET" --scenario "$SCENARIO"

# 2. Wait for telemetry
echo ">> waiting 5s for telemetry to flow"
sleep 5

# 3. Verify ES has events
echo ">> verifying ES has new events"
python3 - <<PY
import os, sys
try:
    from elasticsearch import Elasticsearch
except ImportError:
    print("elasticsearch python client not installed — run scripts/setup/init.sh first", file=sys.stderr)
    sys.exit(2)
es = Elasticsearch(
    os.environ.get("ELASTICSEARCH_URL", "http://localhost:9200"),
    basic_auth=("elastic", os.environ.get("ELASTIC_PASSWORD", "")),
    request_timeout=10,
)
resp = es.search(index="honeypot-events-*", body={"query": {"match_all": {}}, "size": 1, "sort": [{"@timestamp": "desc"}]})
body = resp.body if hasattr(resp, "body") else resp
hits = body["hits"]["hits"]
if not hits:
    print("FAIL: no events found in ES after attack", file=sys.stderr)
    sys.exit(1)
print(f"OK: most recent event @ {hits[0]['_source'].get('@timestamp')}")
PY

# 4. Verify FastAPI /sessions returns at least one session
echo ">> verifying FastAPI /sessions"
python3 - <<PY
import urllib.request, json, sys
try:
    r = urllib.request.urlopen("http://localhost:8000/sessions?size=5", timeout=5)
    j = json.loads(r.read())
    n = len(j.get("sessions", []))
    print(f"OK: /sessions returned {n} sessions")
except Exception as e:
    print(f"FAIL: /sessions unreachable: {e}", file=sys.stderr)
    sys.exit(1)
PY

echo "=== E2E PASSED ==="
